package com.luv2code.springcoredemo;

public interface Coach {
    String getDailyWorkout();
}
